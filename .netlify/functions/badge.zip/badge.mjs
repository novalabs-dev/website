
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/badge.mjs
var ALLOWED_LABELS = ["Minimal", "Needs work", "Decent", "Good", "Excellent"];
function getColor(score) {
  if (score >= 9) return "#22c55e";
  if (score >= 7) return "#10b981";
  if (score >= 5) return "#f59e0b";
  if (score >= 3) return "#f97316";
  return "#ef4444";
}
function generateSvg(score, label) {
  const leftText = "CLAUDE.md";
  const rightText = `${score}/10 ${label}`;
  const color = getColor(score);
  const leftWidth = Math.round(leftText.length * 7) + 20;
  const rightWidth = Math.round(rightText.length * 7) + 20;
  const totalWidth = leftWidth + rightWidth;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${totalWidth}" height="20" role="img" aria-label="${leftText}: ${rightText}">
  <title>${leftText}: ${rightText}</title>
  <linearGradient id="s" x2="0" y2="100%">
    <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>
    <stop offset="1" stop-opacity=".1"/>
  </linearGradient>
  <clipPath id="r">
    <rect width="${totalWidth}" height="20" rx="3" fill="#fff"/>
  </clipPath>
  <g clip-path="url(#r)">
    <rect width="${leftWidth}" height="20" fill="#555"/>
    <rect x="${leftWidth}" width="${rightWidth}" height="20" fill="${color}"/>
    <rect width="${totalWidth}" height="20" fill="url(#s)"/>
  </g>
  <g fill="#fff" text-anchor="middle" font-family="Verdana,Geneva,DejaVu Sans,sans-serif" text-rendering="geometricPrecision" font-size="11">
    <text aria-hidden="true" x="${leftWidth / 2}" y="15" fill="#010101" fill-opacity=".3">${leftText}</text>
    <text x="${leftWidth / 2}" y="14">${leftText}</text>
    <text aria-hidden="true" x="${leftWidth + rightWidth / 2}" y="15" fill="#010101" fill-opacity=".3">${rightText}</text>
    <text x="${leftWidth + rightWidth / 2}" y="14">${rightText}</text>
  </g>
</svg>`;
}
var badge_default = async (req) => {
  const url = new URL(req.url);
  const scoreParam = url.searchParams.get("score");
  const labelParam = url.searchParams.get("label");
  const score = parseFloat(scoreParam);
  if (isNaN(score) || score < 0 || score > 10) {
    return new Response("Invalid score parameter (0-10)", { status: 400 });
  }
  const roundedScore = Math.round(score * 10) / 10;
  if (!labelParam || !ALLOWED_LABELS.includes(labelParam)) {
    return new Response(`Invalid label. Allowed: ${ALLOWED_LABELS.join(", ")}`, { status: 400 });
  }
  const svg = generateSvg(roundedScore, labelParam);
  return new Response(svg, {
    status: 200,
    headers: {
      "Content-Type": "image/svg+xml",
      "Cache-Control": "public, max-age=3600"
    }
  });
};
var config = {
  path: "/api/badge"
};
export {
  config,
  badge_default as default
};
